# Harrison Lilley - Regex Test

1. I applied ^(.+?)(\n\n) and <sp>\1</sp>\2 into the Find and Replace Window, and I then hit "Replace All".

1a. I then expieremented with the Dot Matches All option, and then I noticed that it ends up highlighting all of the text.

1b. \1 and \2 are indicating the specific capture group in Regex.

2. With tagging stage directions or cues, I used the | pipe and then typed in MUSIC|MUSIC.

3. With locating charecters, I used the | pipe to locate specific charecters, such as ANNOUNCER|ANNOUNCER.

4. Finally, I inserted a root element, which was <xml> and </xml>